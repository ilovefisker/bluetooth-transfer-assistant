using System;
using System.Collections.Generic;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace RemoteMedWriterReceiver
{
    internal sealed class FrameParser
    {
        private const int MaxPayloadBytes = 2 * 1024 * 1024;
        private const int MaxHeaderBytes = 256;
        private readonly List<byte> buffer = new List<byte>();

        public void Reset()
        {
            buffer.Clear();
        }

        public ParseBatch Feed(byte[] bytes, int count)
        {
            if (bytes == null) throw new ArgumentNullException("bytes");
            if (count < 0 || count > bytes.Length) throw new ArgumentOutOfRangeException("count");

            for (int index = 0; index < count; index++)
            {
                buffer.Add(bytes[index]);
            }

            ParseBatch batch = new ParseBatch();
            while (TryParseOne(batch))
            {
            }
            return batch;
        }

        private bool TryParseOne(ParseBatch batch)
        {
            int headerEnd = IndexOf(buffer, (byte)'\n', 0);
            if (headerEnd < 0)
            {
                if (buffer.Count > MaxHeaderBytes)
                {
                    Resynchronize();
                }
                return false;
            }

            string header = Encoding.ASCII.GetString(buffer.GetRange(0, headerEnd).ToArray());
            string[] fields = header.Split('|');
            if (fields.Length != 6 || fields[0] != "RMW" || fields[1] != "1" || fields[5] != "")
            {
                buffer.RemoveRange(0, headerEnd + 1);
                batch.Replies.Add("NACK|unknown|BAD_HEADER\n");
                return buffer.Count > 0;
            }

            string messageId = fields[2];
            int payloadLength;
            if (!IsMessageId(messageId)
                || !Int32.TryParse(fields[3], NumberStyles.None, CultureInfo.InvariantCulture,
                    out payloadLength)
                || payloadLength <= 0)
            {
                buffer.RemoveRange(0, headerEnd + 1);
                batch.Replies.Add("NACK|" + SafeId(messageId) + "|BAD_LENGTH\n");
                return buffer.Count > 0;
            }
            if (payloadLength > MaxPayloadBytes)
            {
                buffer.RemoveRange(0, headerEnd + 1);
                batch.Replies.Add("NACK|" + messageId + "|TOO_LARGE\n");
                return buffer.Count > 0;
            }
            if (!IsSha256(fields[4]))
            {
                buffer.RemoveRange(0, headerEnd + 1);
                batch.Replies.Add("NACK|" + messageId + "|BAD_HEADER\n");
                return buffer.Count > 0;
            }

            byte[] suffix = Encoding.ASCII.GetBytes("\nEND|" + messageId + "|\n");
            int frameLength = headerEnd + 1 + payloadLength + suffix.Length;
            if (buffer.Count < frameLength)
            {
                return false;
            }

            int payloadStart = headerEnd + 1;
            byte[] payload = buffer.GetRange(payloadStart, payloadLength).ToArray();
            byte[] actualSuffix = buffer.GetRange(payloadStart + payloadLength, suffix.Length).ToArray();
            buffer.RemoveRange(0, frameLength);

            if (!ByteArraysEqual(suffix, actualSuffix))
            {
                batch.Replies.Add("NACK|" + messageId + "|BAD_SUFFIX\n");
                return buffer.Count > 0;
            }

            string actualHash = ComputeSha256(payload);
            if (!String.Equals(actualHash, fields[4], StringComparison.OrdinalIgnoreCase))
            {
                batch.Replies.Add("NACK|" + messageId + "|BAD_HASH\n");
                return buffer.Count > 0;
            }

            string text;
            try
            {
                UTF8Encoding strictUtf8 = new UTF8Encoding(false, true);
                text = strictUtf8.GetString(payload);
            }
            catch (DecoderFallbackException)
            {
                batch.Replies.Add("NACK|" + messageId + "|BAD_UTF8\n");
                return buffer.Count > 0;
            }

            batch.Messages.Add(new ReceivedMessage(messageId, text, payloadLength));
            batch.Replies.Add("ACK|" + messageId + "\n");
            return buffer.Count > 0;
        }

        private void Resynchronize()
        {
            byte[] marker = Encoding.ASCII.GetBytes("RMW|1|");
            int markerIndex = IndexOf(buffer, marker, 1);
            if (markerIndex >= 0)
            {
                buffer.RemoveRange(0, markerIndex);
            }
            else
            {
                int keep = Math.Min(buffer.Count, marker.Length - 1);
                buffer.RemoveRange(0, buffer.Count - keep);
            }
        }

        private static int IndexOf(List<byte> source, byte value, int start)
        {
            for (int index = start; index < source.Count; index++)
            {
                if (source[index] == value) return index;
            }
            return -1;
        }

        private static int IndexOf(List<byte> source, byte[] pattern, int start)
        {
            for (int index = start; index <= source.Count - pattern.Length; index++)
            {
                bool match = true;
                for (int offset = 0; offset < pattern.Length; offset++)
                {
                    if (source[index + offset] != pattern[offset])
                    {
                        match = false;
                        break;
                    }
                }
                if (match) return index;
            }
            return -1;
        }

        private static bool IsMessageId(string value)
        {
            if (value == null || value.Length != 32) return false;
            for (int index = 0; index < value.Length; index++)
            {
                char character = value[index];
                if (!((character >= '0' && character <= '9')
                      || (character >= 'a' && character <= 'f')
                      || (character >= 'A' && character <= 'F'))) return false;
            }
            return true;
        }

        private static bool IsSha256(string value)
        {
            if (value == null || value.Length != 64) return false;
            for (int index = 0; index < value.Length; index++)
            {
                char character = value[index];
                if (!((character >= '0' && character <= '9')
                      || (character >= 'a' && character <= 'f')
                      || (character >= 'A' && character <= 'F'))) return false;
            }
            return true;
        }

        private static string SafeId(string value)
        {
            return IsMessageId(value) ? value : "unknown";
        }

        private static string ComputeSha256(byte[] bytes)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(bytes);
                StringBuilder result = new StringBuilder(hash.Length * 2);
                for (int index = 0; index < hash.Length; index++)
                {
                    result.Append(hash[index].ToString("x2", CultureInfo.InvariantCulture));
                }
                return result.ToString();
            }
        }

        private static bool ByteArraysEqual(byte[] left, byte[] right)
        {
            if (left.Length != right.Length) return false;
            int difference = 0;
            for (int index = 0; index < left.Length; index++)
            {
                difference |= left[index] ^ right[index];
            }
            return difference == 0;
        }
    }

    internal sealed class ParseBatch
    {
        public readonly List<ReceivedMessage> Messages = new List<ReceivedMessage>();
        public readonly List<string> Replies = new List<string>();
    }

    internal sealed class ReceivedMessage
    {
        public readonly string MessageId;
        public readonly string Text;
        public readonly int ByteLength;

        public ReceivedMessage(string messageId, string text, int byteLength)
        {
            MessageId = messageId;
            Text = text;
            ByteLength = byteLength;
        }
    }
}
