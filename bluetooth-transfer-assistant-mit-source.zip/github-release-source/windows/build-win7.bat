@echo off
setlocal

set "MSBUILD32=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\MSBuild.exe"
if not exist "%MSBUILD32%" (
  echo [ERROR] .NET Framework 4.x MSBuild was not found.
  echo Install .NET Framework 4.0 or Visual Studio 2010 build tools first.
  exit /b 1
)

"%MSBUILD32%" RemoteMedWriterReceiver.csproj /t:Rebuild /p:Configuration=Release /p:Platform=x86
if errorlevel 1 exit /b 1

"%MSBUILD32%" RemoteMedWriterReceiver.csproj /t:Rebuild /p:Configuration=Release /p:Platform=AnyCPU
if errorlevel 1 exit /b 1

echo.
echo Build completed:
echo   bin\Release\x86\RemoteMedWriterReceiver.exe
echo   bin\Release\AnyCPU\RemoteMedWriterReceiver.exe
endlocal

