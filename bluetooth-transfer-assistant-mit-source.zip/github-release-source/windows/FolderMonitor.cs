using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace RemoteMedWriterReceiver
{
    // Local folder observation, not a Bluetooth transfer-complete notification.
    internal sealed class FolderMonitor : IDisposable
    {
        private readonly Timer timer = new Timer();
        private readonly Dictionary<string, string> seen = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, int> pending = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        private string folder;
        public event Action<string> Ready;
        public event Action<string> Failed;
        public FolderMonitor() { timer.Interval = 2000; timer.Tick += Tick; }
        public void Start(string path)
        {
            Stop(); folder = Path.GetFullPath(path);
            if (!Directory.Exists(folder)) throw new DirectoryNotFoundException("请先选择已存在的保存文件夹。");
            foreach (string file in Directory.GetFiles(folder)) seen[file] = Stamp(file);
            timer.Start();
        }
        public void Stop() { timer.Stop(); seen.Clear(); pending.Clear(); }
        private static string Stamp(string path)
        {
            FileInfo f = new FileInfo(path);
            return f.Length + ":" + f.LastWriteTimeUtc.Ticks;
        }
        private void Tick(object sender, EventArgs args)
        {
            bool ready = false;
            try
            {
                HashSet<string> present = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (string path in Directory.GetFiles(folder))
                {
                    present.Add(path);
                    string ext = Path.GetExtension(path).ToLowerInvariant();
                    if (ext == ".tmp" || ext == ".part" || ext == ".crdownload") continue;
                    try
                    {
                        string stamp = Stamp(path), previous;
                        if (!seen.TryGetValue(path, out previous) || stamp != previous)
                        { seen[path] = stamp; pending[path] = 0; continue; }
                        int count;
                        if (!pending.TryGetValue(path, out count)) continue;
                        pending[path] = ++count;
                        if (count < 3) continue;
                        using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.None)) { }
                        pending.Remove(path); ready = true;
                    }
                    catch (IOException) { }
                    catch (UnauthorizedAccessException) { }
                }
                foreach (string path in new List<string>(seen.Keys))
                    if (!present.Contains(path)) { seen.Remove(path); pending.Remove(path); }
                if (ready && Ready != null) Ready(folder);
            }
            catch (Exception e) { Stop(); if (Failed != null) Failed(e.Message); }
        }
        public void Dispose() { Stop(); timer.Dispose(); }
    }
}
