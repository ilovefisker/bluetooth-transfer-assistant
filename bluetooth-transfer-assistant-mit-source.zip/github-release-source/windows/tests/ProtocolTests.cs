using System;
using System.Text;
using System.Security.Cryptography;
namespace RemoteMedWriterReceiver
{
    internal static class ProtocolTests
    {
        const string Id = "0123456789abcdef0123456789abcdef";
        static void Check(bool value, string label) { if (!value) throw new Exception(label); }
        static byte[] Frame(byte[] body)
        {
            string hash;
            using (SHA256 sha = SHA256.Create()) hash = BitConverter.ToString(sha.ComputeHash(body)).Replace("-", "").ToLowerInvariant();
            byte[] header = Encoding.ASCII.GetBytes("RMW|1|" + Id + "|" + body.Length + "|" + hash + "|\n");
            byte[] tail = Encoding.ASCII.GetBytes("\nEND|" + Id + "|\n");
            byte[] frame = new byte[header.Length + body.Length + tail.Length];
            Buffer.BlockCopy(header, 0, frame, 0, header.Length);
            Buffer.BlockCopy(body, 0, frame, header.Length, body.Length);
            Buffer.BlockCopy(tail, 0, frame, header.Length + body.Length, tail.Length);
            return frame;
        }
        static int Main()
        {
            try
            {
                string text = "中文测试\r\n体温36.5℃\nEND|正文内标记|\n";
                byte[] wire = Frame(Encoding.UTF8.GetBytes(text));
                foreach (int size in new int[] {1, 2, 3, 20, 1024})
                {
                    FrameParser parser = new FrameParser(); int messages = 0, acks = 0;
                    for (int offset = 0; offset < wire.Length; offset += size)
                    {
                        int n = Math.Min(size, wire.Length - offset);
                        byte[] chunk = new byte[n + 7]; // unused trailing bytes must be ignored
                        Buffer.BlockCopy(wire, offset, chunk, 0, n);
                        ParseBatch batch = parser.Feed(chunk, n);
                        foreach (ReceivedMessage m in batch.Messages) { Check(m.Text == text, "UTF8 mismatch"); messages++; }
                        foreach (string reply in batch.Replies) { Check(reply == "ACK|" + Id + "\n", "ACK mismatch"); acks++; }
                    }
                    Check(messages == 1 && acks == 1, "fragment count");
                }
                FrameParser reset = new FrameParser(); reset.Feed(wire, wire.Length / 2); reset.Reset();
                Check(reset.Feed(wire, wire.Length).Messages.Count == 1, "reset partial frame");
                byte[] twice = new byte[wire.Length * 2];
                Buffer.BlockCopy(wire, 0, twice, 0, wire.Length); Buffer.BlockCopy(wire, 0, twice, wire.Length, wire.Length);
                Check(new FrameParser().Feed(twice, twice.Length).Messages.Count == 2, "coalesced frames");
                byte[] invalid = Frame(new byte[] { 0xff });
                Check(new FrameParser().Feed(invalid, invalid.Length).Replies[0].Contains("BAD_UTF8"), "invalid UTF8");
                byte[] damaged = (byte[])wire.Clone();
                int bodyStart = Array.IndexOf(damaged, (byte)'\n') + 1; damaged[bodyStart] ^= 1;
                Check(new FrameParser().Feed(damaged, damaged.Length).Replies[0].Contains("BAD_HASH"), "hash validation");
                Console.WriteLine("PASS: fragmentation, UTF8, ACK, actual read count, reset, coalescing, invalid UTF8, checksum.");
                return 0;
            }
            catch (Exception e) { Console.WriteLine("FAIL: " + e.Message); return 1; }
        }
    }
}
