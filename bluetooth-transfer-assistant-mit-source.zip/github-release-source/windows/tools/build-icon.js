// Asset-format conversion only: reuse the APK image without redesigning it.
// Run on macOS: node tools/build-icon.js /absolute/path/to/source.png
const fs = require('fs');
const path = require('path');
const os = require('os');
const cp = require('child_process');
const assert = require('assert');
const source = path.resolve(process.argv[2]);
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'rmw-ico-'));
const sizes = [16, 32, 48, 64, 128, 256];
const images = sizes.map(size => {
  const output = path.join(temp, size + '.png');
  cp.execFileSync('/usr/bin/sips', ['-z', String(size), String(size), source, '--out', output]);
  const data = fs.readFileSync(output);
  assert(data.readUInt32BE(16) === size && data.readUInt32BE(20) === size);
  return data;
});
const header = Buffer.alloc(6 + 16 * sizes.length);
header.writeUInt16LE(1, 2); header.writeUInt16LE(sizes.length, 4);
let offset = header.length;
images.forEach((data, i) => {
  const pos = 6 + i * 16;
  header[pos] = sizes[i] % 256; header[pos + 1] = sizes[i] % 256;
  header.writeUInt16LE(1, pos + 4); header.writeUInt16LE(32, pos + 6);
  header.writeUInt32LE(data.length, pos + 8); header.writeUInt32LE(offset, pos + 12);
  offset += data.length;
});
const target = path.join(__dirname, '..', 'receiver.ico');
fs.writeFileSync(target, Buffer.concat([header, ...images]));
assert(fs.statSync(target).size === offset);
console.log('PASS: ICO directory and PNG dimensions, sizes ' + sizes.join(', ') + '\n' + target);
