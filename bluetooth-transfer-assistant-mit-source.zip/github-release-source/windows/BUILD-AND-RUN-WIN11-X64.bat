@echo off
call "%~dp0BUILD-RECEIVER.bat" x64 Win11-x64
exit /b %ERRORLEVEL%
