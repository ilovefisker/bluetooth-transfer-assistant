using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Windows.Forms;

namespace RemoteMedWriterReceiver
{
    internal sealed class MainForm : Form
    {
        private readonly ComboBox portComboBox = new ComboBox();
        private readonly Button refreshButton = new Button();
        private readonly Button listenButton = new Button();
        private readonly Button copyButton = new Button();
        private readonly Button clearButton = new Button();
        private readonly Button saveButton = new Button();
        private readonly CheckBox autoOpenNotepadCheckBox = new CheckBox();
        private readonly RichTextBox documentTextBox = new RichTextBox();
        private readonly Label statusLabel = new Label();
        private readonly FrameParser parser = new FrameParser();
        private readonly HashSet<string> receivedIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly object serialLock = new object();

        private SerialPort serialPort;
        private readonly FolderMonitor folderMonitor = new FolderMonitor();
        private readonly CheckBox monitorCheck = new CheckBox();
        private readonly TextBox folderBox = new TextBox();
        private readonly Label folderStatus = new Label();
        private readonly Button chooseFolder = new Button();

        public MainForm()
        {
            Text = "蓝牙接收器 · " + (IntPtr.Size == 8 ? "64 位" : "32 位");
            using (Stream iconStream = typeof(MainForm).Assembly.GetManifestResourceStream("ReceiverIcon"))
            {
                if (iconStream != null)
                    using (Icon embedded = new Icon(iconStream)) Icon = (Icon)embedded.Clone();
            }
            MinimumSize = new Size(720, 520);
            Size = new Size(900, 680);
            StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Microsoft YaHei", 9F, FontStyle.Regular, GraphicsUnit.Point);

            BuildLayout();
            RefreshPorts();
            folderMonitor.Ready += delegate(string folder) {
                try {
                    System.Diagnostics.Process.Start("explorer.exe", "\"" + folder + "\"");
                    folderStatus.Text = "检测到新建/更新文件已稳定，已打开保存目录。";
                } catch (Exception e) { folderStatus.Text = "打开目录失败：" + e.Message; }
            };
            folderMonitor.Failed += delegate(string error) { monitorCheck.Checked = false; folderStatus.Text = "监测已停止：" + error; };
            FormClosing += OnFormClosing;
        }

        private void BuildLayout()
        {
            TableLayoutPanel root = new TableLayoutPanel();
            root.Dock = DockStyle.Fill;
            root.Padding = new Padding(12);
            root.ColumnCount = 1;
            root.RowCount = 4;
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 96F));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 110F));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 32F));
            Controls.Add(root);

            FlowLayoutPanel toolbar = new FlowLayoutPanel();
            toolbar.Dock = DockStyle.Fill;
            toolbar.FlowDirection = FlowDirection.LeftToRight;
            toolbar.WrapContents = true;
            toolbar.AutoScroll = true;

            Label portLabel = new Label();
            portLabel.Text = "蓝牙 COM 端口：";
            portLabel.AutoSize = true;
            portLabel.Margin = new Padding(0, 9, 4, 0);
            toolbar.Controls.Add(portLabel);

            portComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            portComboBox.Width = 100;
            portComboBox.Margin = new Padding(0, 4, 6, 0);
            toolbar.Controls.Add(portComboBox);

            ConfigureButton(refreshButton, "刷新端口", RefreshButtonClick);
            ConfigureButton(listenButton, "开始监听", ListenButtonClick);
            ConfigureButton(copyButton, "复制全部", CopyButtonClick);
            ConfigureButton(clearButton, "清空", ClearButtonClick);
            ConfigureButton(saveButton, "另存为 TXT", SaveButtonClick);
            toolbar.Controls.Add(refreshButton);
            toolbar.Controls.Add(listenButton);
            toolbar.Controls.Add(copyButton);
            toolbar.Controls.Add(clearButton);
            toolbar.Controls.Add(saveButton);

            autoOpenNotepadCheckBox.Text = "接收后自动打开记事本";
            autoOpenNotepadCheckBox.Checked = true;
            autoOpenNotepadCheckBox.AutoSize = true;
            autoOpenNotepadCheckBox.Margin = new Padding(8, 9, 0, 0);
            toolbar.Controls.Add(autoOpenNotepadCheckBox);
            root.Controls.Add(toolbar, 0, 0);
            FlowLayoutPanel fileToolbar = new FlowLayoutPanel();
            fileToolbar.Dock = DockStyle.Fill; fileToolbar.AutoScroll = true;
            folderBox.Width = 340; folderBox.ReadOnly = true;
            folderBox.Text = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            chooseFolder.Text = "选择文件保存目录"; chooseFolder.AutoSize = true;
            chooseFolder.Click += delegate {
                using (FolderBrowserDialog dialog = new FolderBrowserDialog()) {
                    dialog.SelectedPath = folderBox.Text;
                    dialog.Description = "选择系统蓝牙实际保存文件的目录（建议专用空文件夹）";
                    if (dialog.ShowDialog(this) == DialogResult.OK) folderBox.Text = dialog.SelectedPath;
                }
            };
            monitorCheck.Text = "监测新文件并打开文件夹"; monitorCheck.AutoSize = true;
            monitorCheck.CheckedChanged += delegate {
                if (monitorCheck.Checked) {
                    try { folderMonitor.Start(folderBox.Text); chooseFolder.Enabled = false; folderStatus.Text = "正在监测；系统蓝牙另行接收并保存到此目录。"; }
                    catch (Exception e) { monitorCheck.Checked = false; folderStatus.Text = e.Message; }
                } else { folderMonitor.Stop(); chooseFolder.Enabled = true; folderStatus.Text = "文件监测已停止。"; }
            };
            folderStatus.AutoSize = true; folderStatus.Text = "请选择实际保存目录后勾选监测；不会自动接收系统蓝牙文件。";
            fileToolbar.Controls.Add(folderBox); fileToolbar.Controls.Add(chooseFolder);
            fileToolbar.SetFlowBreak(chooseFolder, true);
            fileToolbar.Controls.Add(monitorCheck); fileToolbar.SetFlowBreak(monitorCheck, true);
            fileToolbar.Controls.Add(folderStatus); root.Controls.Add(fileToolbar, 0, 1);

            documentTextBox.Dock = DockStyle.Fill;
            documentTextBox.Font = new Font("Microsoft YaHei", 11F, FontStyle.Regular, GraphicsUnit.Point);
            documentTextBox.AcceptsTab = true;
            documentTextBox.DetectUrls = false;
            documentTextBox.HideSelection = false;
            documentTextBox.WordWrap = true;
            documentTextBox.BorderStyle = BorderStyle.FixedSingle;
            root.Controls.Add(documentTextBox, 0, 2);

            statusLabel.Dock = DockStyle.Fill;
            statusLabel.TextAlign = ContentAlignment.MiddleLeft;
            statusLabel.Text = "请选择电脑蓝牙传入 COM 或 BLE 桥接器 COM，然后开始监听。";
            root.Controls.Add(statusLabel, 0, 3);
        }

        private static void ConfigureButton(Button button, string text, EventHandler handler)
        {
            button.Text = text;
            button.AutoSize = true;
            button.Height = 32;
            button.Margin = new Padding(0, 3, 6, 0);
            button.Click += handler;
        }

        private void RefreshButtonClick(object sender, EventArgs e)
        {
            RefreshPorts();
        }

        private void ListenButtonClick(object sender, EventArgs e)
        {
            if (serialPort != null && serialPort.IsOpen)
            {
                StopListening();
            }
            else
            {
                StartListening();
            }
        }

        private void StartListening()
        {
            if (portComboBox.SelectedItem == null)
            {
                SetStatus("没有可用端口。请配置蓝牙 SPP 传入 COM，或插入已安装驱动的 BLE 桥接器。", true);
                return;
            }

            string portName = portComboBox.SelectedItem.ToString();
            SerialPort port = null;
            try
            {
                port = new SerialPort(portName, 115200, Parity.None, 8, StopBits.One);
                port.Handshake = Handshake.None;
                port.Encoding = new UTF8Encoding(false);
                port.ReadBufferSize = 4096;
                port.WriteBufferSize = 1024;
                port.ReadTimeout = 1000;
                port.WriteTimeout = 2000;
                lock (serialLock) { parser.Reset(); serialPort = port; }
                port.DataReceived += SerialDataReceived;
                port.ErrorReceived += SerialErrorReceived;
                port.Open();

                portComboBox.Enabled = false;
                refreshButton.Enabled = false;
                listenButton.Text = "停止监听";
                SetStatus("正在监听 " + portName + "，等待手机发送文字…", false);
            }
            catch (Exception exception)
            {
                lock (serialLock) { serialPort = null; parser.Reset(); }
                if (port != null)
                {
                    port.DataReceived -= SerialDataReceived;
                    port.ErrorReceived -= SerialErrorReceived;
                    port.Dispose();
                }
                SetStatus("无法打开 " + portName + "：" + exception.Message, true);
            }
        }

        private void StopListening()
        {
            SerialPort port = serialPort;
            lock (serialLock) { serialPort = null; parser.Reset(); }
            if (port != null)
            {
                try
                {
                    port.DataReceived -= SerialDataReceived;
                    port.ErrorReceived -= SerialErrorReceived;
                    if (port.IsOpen) port.Close();
                }
                catch
                {
                }
                port.Dispose();
            }
            portComboBox.Enabled = true;
            refreshButton.Enabled = true;
            listenButton.Text = "开始监听";
            SetStatus("监听已停止。", false);
        }

        private void SerialDataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            SerialPort port = sender as SerialPort;
            if (port == null || !port.IsOpen) return;

            try
            {
                int available = port.BytesToRead;
                if (available <= 0) return;
                byte[] bytes = new byte[available];
                int read = port.Read(bytes, 0, bytes.Length);

                ParseBatch batch;
                lock (serialLock)
                {
                    if (!Object.ReferenceEquals(port, serialPort)) return;
                    batch = parser.Feed(bytes, read);
                    foreach (string reply in batch.Replies)
                    {
                        byte[] replyBytes = Encoding.ASCII.GetBytes(reply);
                        port.Write(replyBytes, 0, replyBytes.Length);
                    }
                }

                foreach (ReceivedMessage message in batch.Messages)
                {
                    DisplayMessage(message);
                }
            }
            catch (Exception exception)
            {
                SetStatusFromWorker("接收失败：" + exception.Message, true);
            }
        }

        private void SerialErrorReceived(object sender, SerialErrorReceivedEventArgs e)
        {
            SetStatusFromWorker("串口错误：" + e.EventType, true);
        }

        private void DisplayMessage(ReceivedMessage message)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action<ReceivedMessage>(DisplayMessage), message);
                return;
            }

            if (!receivedIds.Add(message.MessageId))
            {
                SetStatus("已确认重复消息 " + message.MessageId + "，未重复追加。", false);
                return;
            }
            if (receivedIds.Count > 10000) receivedIds.Clear();

            if (documentTextBox.TextLength > 0)
            {
                documentTextBox.AppendText(Environment.NewLine + Environment.NewLine);
            }
            documentTextBox.AppendText(message.Text);
            documentTextBox.SelectionStart = documentTextBox.TextLength;
            documentTextBox.ScrollToCaret();

            if (autoOpenNotepadCheckBox.Checked)
            {
                NotepadOpenResult result = NotepadBridge.OpenWithText(message.Text, message.MessageId);
                SetStatus(result.Success
                        ? "接收并打开记事本成功：" + message.ByteLength + " 字节。" + result.Detail
                        : "文字接收成功，但打开记事本失败：" + result.Detail, !result.Success);
            }
            else
            {
                SetStatus("接收成功：" + message.ByteLength + " 字节，消息 ID " + message.MessageId, false);
            }
        }

        private void RefreshPorts()
        {
            string selected = portComboBox.SelectedItem == null ? null : portComboBox.SelectedItem.ToString();
            string[] names = SerialPort.GetPortNames();
            Array.Sort(names, StringComparer.OrdinalIgnoreCase);
            portComboBox.Items.Clear();
            portComboBox.Items.AddRange(names);
            if (selected != null && portComboBox.Items.Contains(selected))
            {
                portComboBox.SelectedItem = selected;
            }
            else if (portComboBox.Items.Contains("COM3"))
            {
                portComboBox.SelectedItem = "COM3";
            }
            else if (portComboBox.Items.Count > 0)
            {
                portComboBox.SelectedIndex = 0;
            }
            SetStatus(names.Length == 0
                    ? "未发现 COM 端口，请检查蓝牙传入串口或桥接器驱动。"
                    : "发现 " + names.Length + " 个 COM 端口，请选择蓝牙传入 COM 或桥接器 COM。", names.Length == 0);
        }

        private void CopyButtonClick(object sender, EventArgs e)
        {
            if (documentTextBox.TextLength == 0)
            {
                SetStatus("当前没有可复制的文字。", true);
                return;
            }
            Clipboard.SetText(documentTextBox.Text);
            SetStatus("已复制全部文字。", false);
        }

        private void ClearButtonClick(object sender, EventArgs e)
        {
            if (documentTextBox.TextLength == 0) return;
            DialogResult result = MessageBox.Show(this, "确定清空当前窗口中的文字吗？",
                    "确认清空", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                documentTextBox.Clear();
                SetStatus("内容已清空。", false);
            }
        }

        private void SaveButtonClick(object sender, EventArgs e)
        {
            if (documentTextBox.TextLength == 0)
            {
                SetStatus("当前没有可保存的文字。", true);
                return;
            }
            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Filter = "文本文件 (*.txt)|*.txt|所有文件 (*.*)|*.*";
                dialog.DefaultExt = "txt";
                dialog.AddExtension = true;
                dialog.FileName = "接收文字_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".txt";
                if (dialog.ShowDialog(this) != DialogResult.OK) return;

                File.WriteAllText(dialog.FileName, documentTextBox.Text, new UTF8Encoding(true));
                SetStatus("已保存到：" + dialog.FileName, false);
            }
        }

        private void SetStatusFromWorker(string message, bool isError)
        {
            if (IsDisposed) return;
            BeginInvoke(new Action<string, bool>(SetStatus), message, isError);
        }

        private void SetStatus(string message, bool isError)
        {
            statusLabel.ForeColor = isError ? Color.DarkRed : Color.DarkGreen;
            statusLabel.Text = message;
        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            folderMonitor.Dispose();
            StopListening();
        }
    }
}
