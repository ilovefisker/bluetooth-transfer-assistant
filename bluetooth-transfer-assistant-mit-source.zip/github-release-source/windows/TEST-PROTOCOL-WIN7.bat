@echo off
setlocal
cd /d "%~dp0"
set "RMW_CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%RMW_CSC%" (
  echo [ERROR] .NET Framework 4.x compiler not found.
  pause
  exit /b 1
)
if not exist "bin\Win7-x86" mkdir "bin\Win7-x86"
"%RMW_CSC%" /nologo /target:exe /platform:x86 /codepage:65001 /out:"bin\Win7-x86\ProtocolTests.exe" /reference:System.dll /reference:System.Core.dll FrameParser.cs tests\ProtocolTests.cs
if errorlevel 1 (
  pause
  exit /b 1
)
"bin\Win7-x86\ProtocolTests.exe"
set "RMW_TEST_RESULT=%ERRORLEVEL%"
pause
exit /b %RMW_TEST_RESULT%
