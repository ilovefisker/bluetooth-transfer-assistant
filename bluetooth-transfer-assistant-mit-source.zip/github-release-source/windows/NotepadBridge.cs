using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace RemoteMedWriterReceiver
{
    internal static class NotepadBridge
    {
        private const UInt32 WmSetText = 0x000C;

        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern IntPtr FindWindowEx(
            IntPtr parentHandle,
            IntPtr childAfter,
            string className,
            string windowTitle);

        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern IntPtr SendMessage(
            IntPtr windowHandle,
            UInt32 message,
            IntPtr wordParameter,
            string longParameter);

        public static NotepadOpenResult OpenWithText(string text, string messageId)
        {
            string windowsText = NormalizeNewLines(text);
            try
            {
                Process process = Process.Start("notepad.exe");
                if (process == null)
                {
                    return OpenUtf8File(windowsText, messageId, "无法启动空白记事本");
                }

                try
                {
                    process.WaitForInputIdle(5000);
                }
                catch
                {
                }

                IntPtr mainWindow = WaitForMainWindow(process, 5000);
                if (mainWindow != IntPtr.Zero)
                {
                    IntPtr editControl = FindWindowEx(mainWindow, IntPtr.Zero, "Edit", null);
                    if (editControl != IntPtr.Zero)
                    {
                        IntPtr result = SendMessage(editControl, WmSetText, IntPtr.Zero, windowsText);
                        if (result != IntPtr.Zero)
                        {
                            return NotepadOpenResult.Ok("内容通过 Unicode 写入未保存的记事本窗口。");
                        }
                    }
                }

                try
                {
                    if (!process.HasExited) process.CloseMainWindow();
                }
                catch
                {
                }
                return OpenUtf8File(windowsText, messageId, "未找到 Win7 记事本编辑控件");
            }
            catch (Exception exception)
            {
                return OpenUtf8File(windowsText, messageId, exception.Message);
            }
        }

        private static IntPtr WaitForMainWindow(Process process, int timeoutMilliseconds)
        {
            int waited = 0;
            while (waited < timeoutMilliseconds)
            {
                process.Refresh();
                if (process.MainWindowHandle != IntPtr.Zero) return process.MainWindowHandle;
                if (process.HasExited) return IntPtr.Zero;
                Thread.Sleep(100);
                waited += 100;
            }
            return IntPtr.Zero;
        }

        private static NotepadOpenResult OpenUtf8File(
            string text,
            string messageId,
            string primaryFailure)
        {
            try
            {
                string folder = Path.Combine(Path.GetTempPath(), "RemoteMedWriter");
                Directory.CreateDirectory(folder);
                string safeId = String.IsNullOrEmpty(messageId)
                        ? "unknown"
                        : messageId.Substring(0, Math.Min(8, messageId.Length));
                string filename = "接收文字_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff")
                        + "_" + safeId + "_" + Guid.NewGuid().ToString("N") + ".txt";
                string path = Path.Combine(folder, filename);

                // Win7 记事本依靠 BOM 稳定识别 UTF-8，避免中文按本地代码页打开后乱码。
                File.WriteAllText(path, text, new UTF8Encoding(true));
                Process.Start("notepad.exe", "\"" + path + "\"");
                return NotepadOpenResult.Ok(
                        "Unicode 窗口写入不可用，已改用 UTF-8 BOM 临时文件：" + path);
            }
            catch (Exception fallbackException)
            {
                return NotepadOpenResult.Fail(
                        primaryFailure + "；UTF-8 文件回退也失败：" + fallbackException.Message);
            }
        }

        private static string NormalizeNewLines(string text)
        {
            if (text == null) return String.Empty;
            return text.Replace("\r\n", "\n")
                    .Replace("\r", "\n")
                    .Replace("\n", Environment.NewLine);
        }
    }

    internal sealed class NotepadOpenResult
    {
        public readonly bool Success;
        public readonly string Detail;

        private NotepadOpenResult(bool success, string detail)
        {
            Success = success;
            Detail = detail;
        }

        public static NotepadOpenResult Ok(string detail)
        {
            return new NotepadOpenResult(true, detail);
        }

        public static NotepadOpenResult Fail(string detail)
        {
            return new NotepadOpenResult(false, detail);
        }
    }
}
