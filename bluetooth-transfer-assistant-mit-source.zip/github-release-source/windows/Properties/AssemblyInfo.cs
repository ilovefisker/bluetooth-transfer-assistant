using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("病历文字蓝牙接收器")]
[assembly: AssemblyDescription("通过蓝牙虚拟串口接收 UTF-8 病历文字")]
[assembly: AssemblyCompany("RemoteMedWriter")]
[assembly: AssemblyProduct("RemoteMedWriter Receiver")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: ComVisible(false)]
[assembly: Guid("b5e22f1a-38c3-40e8-82a8-f850d222fb53")]
[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]

