@echo off
call "%~dp0BUILD-RECEIVER.bat" x86 Win7-x86
exit /b %ERRORLEVEL%
