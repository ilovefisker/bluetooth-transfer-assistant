@echo off
setlocal
cd /d "%~dp0"
set "RMW_ARCH=%~1"
set "RMW_TARGET=%~2"
if "%RMW_ARCH%"=="x86" goto arch_ok
if "%RMW_ARCH%"=="x64" goto check64
echo [ERROR] Use the Win7-x86 or Win11-x64 launcher.
goto fail
:check64
if /i "%PROCESSOR_ARCHITECTURE%"=="AMD64" goto arch_ok
if /i "%PROCESSOR_ARCHITEW6432%"=="AMD64" goto arch_ok
echo [ERROR] This launcher requires x64 Windows, not 32-bit Windows or ARM64.
goto fail
:arch_ok
set "RMW_CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if "%RMW_ARCH%"=="x64" if exist "%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" set "RMW_CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%RMW_CSC%" (
  echo [ERROR] .NET Framework 4.x compiler not found. Ask your IT administrator.
  goto fail
)
if not exist "bin\%RMW_TARGET%" mkdir "bin\%RMW_TARGET%"
if not exist "bin\%RMW_TARGET%" (
  echo [ERROR] Cannot write output folder. Extract ZIP to a writable local folder.
  goto fail
)
set "RMW_LOG=bin\%RMW_TARGET%\build.log"
set "RMW_TEMP=bin\%RMW_TARGET%\Receiver.build.exe"
echo Building %RMW_TARGET% ...
"%RMW_CSC%" /nologo /target:winexe /platform:%RMW_ARCH% /optimize+ /codepage:65001 /win32icon:receiver.ico /resource:receiver.ico,ReceiverIcon /out:"%RMW_TEMP%" /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:System.Security.dll Program.cs MainForm.cs FrameParser.cs FolderMonitor.cs NotepadBridge.cs Properties\AssemblyInfo.cs >"%RMW_LOG%" 2>&1
if errorlevel 1 (
  type "%RMW_LOG%"
  echo [ERROR] Build failed. Existing installed EXE was not replaced.
  echo Send build.log to the developer.
  goto fail
)
copy /y "%RMW_TEMP%" "bin\%RMW_TARGET%\RemoteMedWriterReceiver.exe" >nul
if errorlevel 1 (
  echo [ERROR] Close the running receiver and try again. No process was killed.
  goto fail
)
echo [OK] Starting %RMW_TARGET%. COM3 is preferred when available.
start "" "%~dp0bin\%RMW_TARGET%\RemoteMedWriterReceiver.exe"
exit /b 0
:fail
pause
exit /b 1
