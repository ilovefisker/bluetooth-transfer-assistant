#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
SDK_ROOT="${ANDROID_SDK_ROOT:-/opt/homebrew/share/android-commandlinetools}"
JDK_ROOT="${RMW_JDK_ROOT:-/opt/homebrew/opt/openjdk@17}"
export JAVA_HOME="$JDK_ROOT"
export PATH="$JDK_ROOT/bin:$PATH"
BT="$SDK_ROOT/build-tools/35.0.0"
ANDROID_JAR="$SDK_ROOT/platforms/android-35/android.jar"
BUILD_DIR="$(mktemp -d "${TMPDIR:-/tmp}/rmw-apk.XXXXXX")"
mkdir -p "$BUILD_DIR/classes" "$BUILD_DIR/dex" "$BUILD_DIR/res" signing
"$BT/aapt" package -f -M AndroidManifest.xml -S res -I "$ANDROID_JAR" -F "$BUILD_DIR/base.apk"
"$JDK_ROOT/bin/javac" --release 8 -encoding UTF-8 -classpath "$ANDROID_JAR" -d "$BUILD_DIR/classes" src/cn/remotemedwriter/android/*.java
"$JDK_ROOT/bin/jar" cf "$BUILD_DIR/classes.jar" -C "$BUILD_DIR/classes" .
"$BT/d8" --lib "$ANDROID_JAR" --min-api 23 --output "$BUILD_DIR/dex" "$BUILD_DIR/classes.jar"
cp "$BUILD_DIR/base.apk" "$BUILD_DIR/unsigned.apk"
(cd "$BUILD_DIR/dex"; zip -q "$BUILD_DIR/unsigned.apk" classes.dex)
"$BT/zipalign" -f -p 4 "$BUILD_DIR/unsigned.apk" "$BUILD_DIR/aligned.apk"
if [ ! -f signing/debug.keystore ]; then
  "$JDK_ROOT/bin/keytool" -genkeypair -keystore signing/debug.keystore -storepass android -keypass android -alias androiddebugkey -dname "CN=Android Debug,O=RemoteMedWriter,C=CN" -keyalg RSA -keysize 2048 -validity 10000
fi
"$BT/apksigner" sign --ks signing/debug.keystore --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out ../remote-med-writer-android-0.3.1-debug.apk "$BUILD_DIR/aligned.apk"
"$BT/apksigner" verify --verbose ../remote-med-writer-android-0.3.1-debug.apk
"$BT/aapt" dump badging ../remote-med-writer-android-0.3.1-debug.apk
printf 'Build intermediates: %s\n' "$BUILD_DIR"
