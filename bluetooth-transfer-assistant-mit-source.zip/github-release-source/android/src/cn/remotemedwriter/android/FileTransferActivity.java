package cn.remotemedwriter.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.concurrent.*;

/** Files are handed to the system; no RMW framing or content conversion. */
final class FileTransferActivity extends ContextWrapper {
    private final Activity host;
    FileTransferActivity(Activity host){super(host);this.host=host;}
    private void runOnUiThread(Runnable action){host.runOnUiThread(action);}
    private static final int PICK = 201;
    private final ExecutorService reader = Executors.newSingleThreadExecutor();
    private LinearLayout root;
    private TextView details, status;
    private Button send;
    private Uri selected;
    private String name = "所选文件", mime = "application/octet-stream";
    private int generation;
    private boolean destroyed;

    View createView(Bundle state) {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22),dp(22),dp(22),dp(28));
        root.setBackgroundColor(Color.rgb(244,247,251));
        root.setBackgroundColor(Ui.BG);
        scroll.addView(root);
        label("把文件发到电脑",22);
        label("文档、图片或 PDF · 原文件传输",14);
        button("选择 / 更换文件",v->pick());
        details=label("尚未选择文件",16);
        send=button("分享文件 · 选择蓝牙",v->confirm()); Ui.primary(send);send.setEnabled(false);
        status=label("等待选择文件。",15);
        label("电脑请先开启“接收文件”。发送结果以系统通知为准。",14);
        LinearLayout page=root;root=Ui.fold(page,"文件选项与使用说明");
        button("清除选择",v->{generation++;selected=null;send.setEnabled(false);details.setText("尚未选择文件");status.setText("已清除选择，原文件未删除。");});
        button("打开手机蓝牙设置",v->{
            try { startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); }
            catch(ActivityNotFoundException e){status.setText("无法打开蓝牙设置，请手动进入系统设置。");}
        });
        label("先在电脑打开蓝牙的“接收文件”，并与手机配对。分享时手动选择“蓝牙”和目标电脑。本页不会自动指定设备。请选择手机本地文件；云盘文件可能需要先下载。",14);
        label("传输进度和结果请查看系统蓝牙通知及电脑。若分享面板没有“蓝牙”，请取消并检查手机是否提供蓝牙文件分享。不要误选微信或云盘，以免将文件发往其他渠道。",14);
        label("文件原样交给系统，不重新编码。此模式不会自动打开电脑记事本；需要自动显示文字时，请返回“文字传输”。含个人信息的文件请先脱敏。",14);
        root=page;
        if(state!=null){String uri=state.getString("fileUri");if(uri!=null)load(Uri.parse(uri));}
        return scroll;
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    private TextView label(String text,int size){return Ui.label(root,text,size);}
    private Button button(String text,View.OnClickListener listener){return Ui.button(root,text,listener);}
    private void pick(){
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_LOCAL_ONLY,true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {host.startActivityForResult(intent,PICK);}
        catch(ActivityNotFoundException e){status.setText("系统没有可用的文件选择器。");}
    }
    void onActivityResult(int request,int result,Intent data){
        if(request==PICK && result==Activity.RESULT_OK && data!=null && data.getData()!=null)load(data.getData());
    }
    private void load(Uri uri){
        final int ticket=++generation;
        selected=null;send.setEnabled(false);
        if(!"content".equals(uri.getScheme())){status.setText("文件提供方返回了不支持的地址，请重新选择。");return;}
        details.setText("正在读取文件信息…");status.setText("不会读取或预览文件正文。");
        reader.submit(()->{
            String display="所选文件",type="application/octet-stream";long size=-1;
            try {
                String found=getContentResolver().getType(uri);if(found!=null)type=found;
                try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)){
                    if(c!=null && c.moveToFirst()){
                        int n=c.getColumnIndex(OpenableColumns.DISPLAY_NAME),s=c.getColumnIndex(OpenableColumns.SIZE);
                        if(n>=0 && !c.isNull(n))display=c.getString(n);
                        if(s>=0 && !c.isNull(s))size=c.getLong(s);
                    }
                }
                final String fileName=display,fileType=type;
                final long length=size;
                runOnUiThread(()->{if(destroyed || ticket!=generation)return;
                    selected=uri;name=fileName;mime=fileType;
                    details.setText("文件："+name+"\n类型："+mime+"\n大小："+(length<0?"未知（由系统处理）":length+" 字节"));
                    send.setEnabled(true);status.setText("已选择，尚未发送。请确认电脑正在等待接收。");
                });
            }catch(Exception e){runOnUiThread(()->{if(!destroyed && ticket==generation){details.setText("无法读取文件信息");status.setText("文件不可访问，请重新选择手机本地文件。");}});}
        });
    }
    private void confirm(){
        if(selected==null)return;
        final Uri uri=selected;final String type=mime;
        new AlertDialog.Builder(host).setTitle("确认分享文件")
            .setMessage(name+"\n\n下一步请只选择“蓝牙”，并核对接收电脑。系统分享面板也可能列出其他应用。")
            .setNegativeButton("取消",null).setPositiveButton("继续",(d,w)->{
                Intent share=new Intent(Intent.ACTION_SEND).setType(type);
                share.putExtra(Intent.EXTRA_STREAM,uri);
                share.setClipData(ClipData.newRawUri("文件",uri));
                share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try{
                    startActivity(Intent.createChooser(share,"请选择蓝牙，再选择接收电脑"));
                    status.setText("已打开系统分享面板，未确认发送成功。请查看系统蓝牙通知及电脑；取消分享不会发送文件。");
                }catch(ActivityNotFoundException e){status.setText("没有可用的系统分享应用。");}
                catch(SecurityException e){status.setText("文件读取授权已失效，请重新选择文件。");}
            }).show();
    }
    void saveState(Bundle state){if(selected!=null)state.putString("fileUri",selected.toString());}
    void destroy(){destroyed=true;generation++;reader.shutdownNow();}
}
