package cn.remotemedwriter.android;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.*;

final class Ui {
    static final int BLUE=Color.rgb(38,88,214), INK=Color.rgb(25,39,62), BG=Color.rgb(245,247,252);
    static int dp(Context c,int n){return (int)(n*c.getResources().getDisplayMetrics().density);}
    static GradientDrawable shape(Context c,int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(c,radius));return d;}
    static TextView label(LinearLayout parent,String text,int size){
        Context c=parent.getContext();TextView v=new TextView(c);v.setText(text);v.setTextSize(size);v.setTextColor(INK);
        v.setPadding(0,dp(c,10),0,dp(c,8));v.setLineSpacing(dp(c,3),1);
        if(size>=19)v.setTypeface(null,Typeface.BOLD);parent.addView(v);return v;
    }
    static Button button(LinearLayout parent,String text,View.OnClickListener action){
        Context c=parent.getContext();Button b=new Button(c);b.setText(text);b.setAllCaps(false);b.setTextSize(15);
        b.setMinHeight(dp(c,48));b.setTextColor(BLUE);b.setBackground(shape(c,Color.WHITE,12));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(c,4),0,dp(c,4));parent.addView(b,p);b.setOnClickListener(action);return b;
    }
    static void primary(Button b){Context c=b.getContext();
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_enabled},new int[]{}},new int[]{BLUE,Color.rgb(151,166,192)}));
    }
    static LinearLayout fold(LinearLayout parent,String title){
        Button toggle=button(parent,title+"  ＋",null);
        LinearLayout body=new LinearLayout(parent.getContext());body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(parent.getContext(),12),0,dp(parent.getContext(),12),dp(parent.getContext(),12));
        parent.addView(body);body.setVisibility(View.GONE);
        toggle.setOnClickListener(v->{boolean open=body.getVisibility()!=View.VISIBLE;body.setVisibility(open?View.VISIBLE:View.GONE);toggle.setText(title+(open?"  −":"  ＋"));});
        return body;
    }
}
