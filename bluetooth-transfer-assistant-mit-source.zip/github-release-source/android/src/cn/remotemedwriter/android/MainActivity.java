package cn.remotemedwriter.android;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.*;
import android.provider.Settings;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ScheduledExecutorService timers = Executors.newSingleThreadScheduledExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<BluetoothDevice> devices = new ArrayList<>();
    private BluetoothAdapter adapter;
    private volatile Link active;
    private volatile boolean destroyed;
    private boolean busy;
    private LinearLayout root;
    private EditText address, body;
    private Spinner paired, mode;
    private TextView status, count;
    private ProgressBar progress;
    private Button send, paste, clear, refresh, settings;
    private String retryText, retryId, retryTarget;
    private FileTransferActivity files;
    private View textPage,filePage;
    private Button textTab,fileTab,cancel;
    private int selectedTab;

    private void selectTab(int tab){
        selectedTab=tab;
        textPage.setVisibility(tab==0?View.VISIBLE:View.GONE);filePage.setVisibility(tab==1?View.VISIBLE:View.GONE);
        textTab.setSelected(tab==0);fileTab.setSelected(tab==1);
        textTab.setTextColor(tab==0?Color.WHITE:Ui.BLUE);fileTab.setTextColor(tab==1?Color.WHITE:Ui.BLUE);
        textTab.setBackground(Ui.shape(this,tab==0?Ui.BLUE:Color.WHITE,14));
        fileTab.setBackground(Ui.shape(this,tab==1?Ui.BLUE:Color.WHITE,14));
        ((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(textTab.getWindowToken(),0);
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        BluetoothManager manager = (BluetoothManager)getSystemService(BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);shell.setBackgroundColor(Ui.BG);
        setContentView(shell);
        getWindow().setStatusBarColor(Ui.BG);getWindow().setNavigationBarColor(Ui.BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        LinearLayout tabs=new LinearLayout(this);tabs.setPadding(dp(20),dp(12),dp(20),dp(8));shell.addView(tabs);
        textTab=new Button(this);fileTab=new Button(this);textTab.setText("文字传输");fileTab.setText("文件传输");
        for(Button b:new Button[]{textTab,fileTab}){b.setAllCaps(false);b.setTextSize(16);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(52),1);p.setMargins(dp(3),0,dp(3),0);tabs.addView(b,p);}
        FrameLayout pages=new FrameLayout(this);shell.addView(pages,new LinearLayout.LayoutParams(-1,0,1));
        ScrollView scroll = new ScrollView(this);textPage=scroll;
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22),dp(22),dp(22),dp(28)); root.setBackgroundColor(Color.rgb(244,247,251));
        root.setBackgroundColor(Ui.BG);
        scroll.addView(root);pages.addView(scroll);
        if (Build.VERSION.SDK_INT >= 35) shell.setOnApplyWindowInsetsListener((v,i)->{
            android.graphics.Insets in = i.getInsets(WindowInsets.Type.systemBars());
            v.setPadding(in.left,in.top,in.right,in.bottom); return i;
        });
        label("把文字送到记事本",22);
        label("粘贴文字或 OCR 结果，发送前请核对并脱敏。",14);
        LinearLayout page=root;
        root=Ui.fold(page,"接收设备与连接方式");
        settings = button("打开系统蓝牙设置",v->startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)));
        refresh = button("刷新已配对设备",v->loadDevices());
        paired = new Spinner(this); root.addView(paired);
        address = new EditText(this); address.setSingleLine(true);
        address.setHint("蓝牙设备地址"); root.addView(address);
        paired.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onItemSelected(AdapterView<?> parent, View v, int p, long id) { if(p > 0 && p <= devices.size()) address.setText(devices.get(p-1).getAddress()); }
            public void onNothingSelected(AdapterView<?> parent) {}
        });
        mode = new Spinner(this);
        ArrayAdapter<String> modes = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"经典蓝牙串口（电脑 SPP）", "BLE 桥接器（RMW 服务）"});
        mode.setAdapter(modes); root.addView(mode);
        label("经典模式：电脑需启用蓝牙传入 COM，并启动接收程序。BLE 模式：需配套 ESP32 串口桥。系统文件发送成功不代表文字通道已就绪。",14);
        root=page;
        body = new EditText(this); body.setGravity(Gravity.TOP); body.setMinLines(7);
        body.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        body.setHint("在这里输入或粘贴文字…");body.setTextSize(17);body.setPadding(dp(16),dp(16),dp(16),dp(16));body.setBackground(Ui.shape(this,Color.WHITE,16)); root.addView(body);
        count = label("0 字符 · 0 字节",14);
        body.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int c){
                count.setText(s.length()+" 字符 · "+s.toString().getBytes(StandardCharsets.UTF_8).length+" 字节");
                retryId=null; retryText=null;
            }
            public void afterTextChanged(Editable e){}
        });
        paste = button("粘贴文字",v->{
            android.content.ClipboardManager clipboard=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            ClipData data=clipboard.getPrimaryClip();
            if(data != null && data.getItemCount()>0) body.setText(data.getItemAt(0).coerceToText(this));
            else status.setText("剪贴板里没有文字");
        });
        progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setMax(100); root.addView(progress);
        send = button("连接并发送文字",v->confirmSend());
        Ui.primary(send);
        cancel=button("取消当前传输",v->{Link link=active;if(link!=null)link.close();});cancel.setVisibility(View.GONE);
        status = label("准备就绪。请先核对设备和正文。",15);
        root=Ui.fold(page,"更多操作与使用说明");
        clear = button("清空内容",v->new AlertDialog.Builder(this).setTitle("清空当前文字？").setMessage("清空后无法恢复。").setNegativeButton("取消",null).setPositiveButton("清空",(d,w)->body.setText("")).show());
        label("OCR 当前使用识别后粘贴；接收完成后，电脑端负责自动打开记事本。",14);
        label("Android 0.3.1 · 本地蓝牙传输\n标签切换保留当前内容；退出或旋转屏幕可能中断文字传输。",14);
        root=page;
        files=new FileTransferActivity(this);filePage=files.createView(state);pages.addView(filePage);
        textTab.setOnClickListener(v->selectTab(0));
        fileTab.setOnClickListener(v->{if(busy){status.setText("文字正在传输，请完成或取消后切换。");return;}selectTab(1);});
        selectTab(state==null?0:state.getInt("selectedTab",0));
        if(Intent.ACTION_SEND.equals(getIntent().getAction())) {
            CharSequence shared=getIntent().getCharSequenceExtra(Intent.EXTRA_TEXT);
            if(shared!=null){body.setText(shared);selectTab(0);}
        }
        if(permitted())loadDevices();
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    private TextView label(String text,int size){return Ui.label(root,text,size);}
    private Button button(String text,View.OnClickListener listener){return Ui.button(root,text,listener);}
    private boolean permitted(){return Build.VERSION.SDK_INT<31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;}
    private void loadDevices(){
        if(busy)return;
        if(adapter==null){status.setText("这台设备不支持蓝牙");return;}
        if(!permitted()){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},1);return;}
        try {
            devices.clear(); devices.addAll(adapter.getBondedDevices());
            List<String> names=new ArrayList<>(); names.add("选择已配对设备，或使用下方地址");
            for(BluetoothDevice d:devices) names.add((d.getName()==null?"未命名设备":d.getName())+" · "+d.getAddress());
            paired.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));
            status.setText(adapter.isEnabled()?"找到 "+devices.size()+" 个已配对设备，请核对接收地址":"请先开启系统蓝牙");
        } catch(Exception e){status.setText("读取设备失败："+e.getMessage());}
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==1){if(permitted())loadDevices();else status.setText("需要允许“附近设备”权限才能连接蓝牙");}}
    private void confirmSend(){
        if(busy)return;
        if(!permitted()){loadDevices();return;}
        String target=address.getText().toString().trim().toUpperCase(Locale.ROOT);
        if(!BluetoothAdapter.checkBluetoothAddress(target)){status.setText("请选择已配对电脑，或填写该电脑实际蓝牙地址");return;}
        if(adapter==null || !adapter.isEnabled()){status.setText("请开启系统蓝牙");return;}
        final String text=body.getText().toString(); final boolean ble=mode.getSelectedItemPosition()==1;
        try {
            String key=target+"/"+ble;
            Frame frame=new Frame(text,text.equals(retryText)&&key.equals(retryTarget)?retryId:null);
            new AlertDialog.Builder(this).setTitle("确认发送")
                .setMessage("目标："+target+"\n正文："+frame.payloadSize+" 字节\n电脑接收程序需要正在监听。")
                .setNegativeButton("取消",null).setPositiveButton("发送",(d,w)->startSend(target,ble,text,frame)).show();
        }catch(Exception e){status.setText(e.getMessage());}
    }
    private void controls(boolean value){busy=value;cancel.setVisibility(value?View.VISIBLE:View.GONE);for(View v:new View[]{body,address,paired,mode,send,paste,clear,refresh,settings,fileTab})v.setEnabled(!value);}
    private void ui(Runnable r){main.post(()->{if(!destroyed)r.run();});}
    private void startSend(String target,boolean ble,String text,Frame frame){
        if(busy)return;
        controls(true); progress.setProgress(0); status.setText("正在连接设备…");
        final Link link=new Link();active=link;
        worker.submit(()->{
            ScheduledFuture<?> deadline=timers.schedule(link::close,45,TimeUnit.SECONDS);
            try {
                link.connect(getApplicationContext(),adapter.getRemoteDevice(target),ble);
                deadline.cancel(false);
                // A separate bound covers blocked SPP writes and unexpectedly slow transfers.
                deadline=timers.schedule(link::close,30,TimeUnit.MINUTES);
                ui(()->status.setText("通道已连接，正在发送文字…"));
                final int[] last={-1};
                link.send(frame,percent->{if(last[0]!=percent){last[0]=percent;ui(()->{progress.setProgress(percent);if(percent==99)status.setText("已写入，等待电脑确认…");});}});
                ui(()->{retryId=null;retryText=null;status.setText("电脑已确认完整接收。记事本打开结果请查看电脑接收器。");});
            }catch(Exception e){
                ui(()->{retryId=frame.id;retryText=text;retryTarget=target+"/"+ble;status.setText("未确认成功："+e.getMessage()+"\n请检查电脑接收程序。若中途断开，请退出并重新打开电脑接收程序后再重试；先检查记事本，避免重复接收。");});
            }finally{deadline.cancel(false);link.close();if(active==link)active=null;ui(()->controls(false));}
        });
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(files!=null)files.onActivityResult(request,result,data);}
    @Override protected void onSaveInstanceState(Bundle state){super.onSaveInstanceState(state);state.putInt("selectedTab",selectedTab);if(files!=null)files.saveState(state);}
    @Override protected void onDestroy(){destroyed=true;if(files!=null)files.destroy();Link link=active;if(link!=null)link.close();worker.shutdownNow();timers.shutdownNow();main.removeCallbacksAndMessages(null);super.onDestroy();}
}
