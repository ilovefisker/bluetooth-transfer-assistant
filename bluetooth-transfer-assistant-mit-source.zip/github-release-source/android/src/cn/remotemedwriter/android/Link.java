package cn.remotemedwriter.android;

import android.bluetooth.*;
import android.content.Context;
import android.os.Build;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

// All blocking operations run on the Activity's worker, never the UI thread.
final class Link implements Closeable {
    private static final UUID SERVICE = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID RX = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID TX = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private volatile BluetoothSocket socket;
    private volatile BluetoothGatt gatt;
    private BluetoothGattCharacteristic rx;
    private final BlockingQueue<Integer> events = new LinkedBlockingQueue<>();
    private final BlockingQueue<Integer> incoming = new ArrayBlockingQueue<>(4096);
    private volatile boolean closed;
    private boolean ble;

    private final BluetoothGattCallback callback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int state) {
            if (closed) return;
            if (status == BluetoothGatt.GATT_SUCCESS && state == BluetoothProfile.STATE_CONNECTED) events.offer(0);
            else if (state == BluetoothProfile.STATE_DISCONNECTED || status != 0) {
                closed = true; events.offer(-1); incoming.offer(-1);
            }
        }
        @Override public void onServicesDiscovered(BluetoothGatt g, int status) { events.offer(status); }
        @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) { events.offer(status); }
        @Override public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic c, int status) { events.offer(status); }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) { receive(c.getUuid(), c.getValue()); }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value) { receive(c.getUuid(), value); }
    };

    private void receive(UUID id, byte[] value) {
        if (!TX.equals(id) || value == null || closed) return;
        for (byte b : value) if (!incoming.offer(b & 255)) { close(); break; }
    }

    void connect(Context context, BluetoothDevice device, boolean useBle) throws Exception {
        ble = useBle;
        if (closed) throw new IOException("已取消连接");
        if (!ble) {
            BluetoothSocket created = device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805f9b34fb"));
            synchronized (this) { if (closed) { created.close(); throw new IOException("已取消连接"); } socket = created; }
            socket.connect();
            return;
        }
        synchronized (this) {
            if (closed) throw new IOException("已取消连接");
            gatt = device.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE);
        }
        if (gatt == null) throw new IOException("无法启动 BLE 连接");
        await("连接 BLE");
        if (!gatt.discoverServices()) throw new IOException("无法查询 BLE 服务");
        await("查询服务");
        BluetoothGattService service = gatt.getService(SERVICE);
        if (service == null) throw new IOException("设备没有 RMW 文字服务，请使用已烧录固件的 BLE 串口桥接器");
        rx = service.getCharacteristic(RX);
        BluetoothGattCharacteristic tx = service.getCharacteristic(TX);
        if (rx == null || tx == null || (rx.getProperties() & BluetoothGattCharacteristic.PROPERTY_WRITE) == 0
                || (tx.getProperties() & BluetoothGattCharacteristic.PROPERTY_NOTIFY) == 0)
            throw new IOException("设备缺少匹配的写入/通知特征");
        if (!gatt.setCharacteristicNotification(tx, true)) throw new IOException("无法订阅回复");
        BluetoothGattDescriptor descriptor = tx.getDescriptor(CCCD);
        if (descriptor == null) throw new IOException("设备缺少通知描述符");
        if (Build.VERSION.SDK_INT >= 33) {
            if (gatt.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) != 0) throw new IOException("订阅请求失败");
        } else {
            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            if (!gatt.writeDescriptor(descriptor)) throw new IOException("订阅请求失败");
        }
        await("订阅回复");
    }

    private void await(String operation) throws Exception {
        Integer status = events.poll(12, TimeUnit.SECONDS);
        if (closed || status == null || status != 0) throw new IOException(operation + "失败或超时（" + status + "）");
    }

    interface Progress { void update(int percent); }
    void send(Frame frame, Progress progress) throws Exception {
        int chunkSize = ble ? 20 : 1024;
        for (int offset = 0; offset < frame.bytes.length; offset += chunkSize) {
            if (closed) throw new IOException("连接已断开或传输已取消");
            int end = Math.min(offset + chunkSize, frame.bytes.length);
            if (ble) {
                byte[] part = Arrays.copyOfRange(frame.bytes, offset, end);
                if (Build.VERSION.SDK_INT >= 33) {
                    if (gatt.writeCharacteristic(rx, part, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) != 0) throw new IOException("BLE 写入请求失败");
                } else {
                    rx.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT); rx.setValue(part);
                    if (!gatt.writeCharacteristic(rx)) throw new IOException("BLE 写入请求失败");
                }
                await("写入分片");
            } else socket.getOutputStream().write(frame.bytes, offset, end - offset);
            progress.update((int)(99L * end / frame.bytes.length));
        }
        if (!ble) socket.getOutputStream().flush();
        // Closing the link unblocks RFCOMM reads on timeout/cancellation.
        ScheduledExecutorService clock = Executors.newSingleThreadScheduledExecutor();
        ScheduledFuture<?> timeout = clock.schedule(this::close, 15, TimeUnit.SECONDS);
        try {
            StringBuilder line = new StringBuilder();
            int total = 0;
            while (!closed) {
                Integer value;
                if (ble) value = incoming.poll(15, TimeUnit.SECONDS);
                else value = socket.getInputStream().read();
                if (value == null || value < 0) throw new IOException("未收到电脑确认，连接断开或超时");
                if (++total > 4096) throw new IOException("电脑回复格式不正确");
                if (value == '\n') {
                    String response = line.toString().trim(); line.setLength(0);
                    if (response.equals("ACK|" + frame.id)) { progress.update(100); return; }
                    if (response.startsWith("NACK|" + frame.id + "|")) throw new IOException("电脑拒绝接收：" + response);
                } else {
                    line.append((char)(int)value);
                    if (line.length() > 256) throw new IOException("电脑回复过长");
                }
            }
            throw new IOException("等待电脑确认超时");
        } finally { timeout.cancel(false); clock.shutdownNow(); }
    }

    @Override public synchronized void close() {
        closed = true; events.offer(-1); incoming.offer(-1);
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        try { if (gatt != null) { gatt.disconnect(); gatt.close(); } } catch (Exception ignored) {}
    }
}
