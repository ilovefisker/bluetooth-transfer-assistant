package cn.remotemedwriter.android;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;
import java.io.ByteArrayOutputStream;

public final class Frame {
    public final String id;
    public final byte[] bytes;
    public final int payloadSize;
    public Frame(String text, String existingId) throws Exception {
        if (text.indexOf('\0') >= 0) throw new IllegalArgumentException("正文含有不可显示的空字符，请删除后发送");
        byte[] payload = text.getBytes(StandardCharsets.UTF_8);
        if (payload.length == 0 || payload.length > 2 * 1024 * 1024)
            throw new IllegalArgumentException("请输入 1 字节至 2 MB 的文字");
        id = existingId == null ? UUID.randomUUID().toString().replace("-", "") : existingId;
        StringBuilder hash = new StringBuilder();
        for (byte b : MessageDigest.getInstance("SHA-256").digest(payload)) hash.append(String.format("%02x", b & 255));
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(("RMW|1|" + id + "|" + payload.length + "|" + hash + "|\n").getBytes(StandardCharsets.US_ASCII));
        out.write(payload);
        out.write(("\nEND|" + id + "|\n").getBytes(StandardCharsets.US_ASCII));
        bytes = out.toByteArray();
        payloadSize = payload.length;
    }
}
