import cn.remotemedwriter.android.Frame;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class FrameTest {
    static void check(boolean result) { if (!result) throw new AssertionError(); }
    static void rejected(String text) throws Exception {
        try { new Frame(text, null); throw new AssertionError("accepted invalid text"); }
        catch (IllegalArgumentException expected) { }
    }
    public static void main(String[] args) throws Exception {
        String id = "0123456789abcdef0123456789abcdef";
        Frame known = new Frame("abc", id);
        check(new String(known.bytes, StandardCharsets.UTF_8).equals("RMW|1|" + id + "|3|ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad|\nabc\nEND|" + id + "|\n"));
        String text = "中文病历\r\n体温：36.5℃ 😊\nEND|假标记|\n";
        Frame unicode = new Frame(text, null);
        check(unicode.id.matches("[0-9a-f]{32}"));
        check(unicode.payloadSize == text.getBytes(StandardCharsets.UTF_8).length);
        String encoded = new String(unicode.bytes, StandardCharsets.UTF_8);
        check(encoded.substring(encoded.indexOf('\n') + 1).equals(text + "\nEND|" + unicode.id + "|\n"));
        check(Arrays.equals(unicode.bytes, new Frame(text, unicode.id).bytes));
        rejected(""); rejected("a\0b");
        char[] limit = new char[2 * 1024 * 1024]; Arrays.fill(limit, 'a');
        check(new Frame(new String(limit), null).payloadSize == limit.length);
        rejected(new String(limit) + "a");
        System.out.println("PASS: known SHA-256 frame, UTF-8 roundtrip, retry ID, empty/NUL/size validation");
    }
}
