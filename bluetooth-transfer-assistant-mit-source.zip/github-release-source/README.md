# 蓝牙文字与文件传输助手

Android → Windows 本地蓝牙传输工具：文字接收后自动在记事本显示，文件通过手机系统蓝牙分享传输。

## 功能

- 安卓“文字传输 / 文件传输”双标签页，辅助设置折叠。
- 文字采用 RMW 协议，经经典蓝牙 SPP 或配套 BLE 串口桥发送；校验完整性并回复 ACK。
- Windows 接收器优先选择 COM3，自动打开记事本显示中文正文。
- 可选文件夹监测：新建或更新文件稳定约 6 秒后打开保存目录。
- 不含 AI、医学知识库或内置 OCR；OCR 结果可从其他应用复制后粘贴。

## 安装与使用

详细步骤：[手机 APK 与电脑接收器安装说明](docs/INSTALL.md)。

| 平台 | 当前提供内容 |
| --- | --- |
| Android 6.0+ | 原生 Java 源码，版本 0.3.1，手动构建脚本 |
| Win7 32 位 | x86 一键编译入口，需兼容的 .NET Framework 4.x |
| Win11 Intel/AMD 64 位 | x64 一键编译入口，非 ARM64 版本 |

当前仓库发布源码，不包含预编译 APK/EXE。用户曾进行部分功能测试，但 Windows 两种架构和新版界面尚未完成系统性真机验证。不要将编译成功理解为全平台兼容保证。

### Android 构建

准备 JDK 17、Android SDK Platform 35、Build Tools 35.0.0 和 zip，然后执行：

```sh
cd android
ANDROID_SDK_ROOT=/path/to/android-sdk RMW_JDK_ROOT=/path/to/jdk17 bash build.sh
```

脚本不依赖 Gradle，输出在 android 的上一级。首次构建会在 android/signing 生成本地测试签名密钥，请自行安全保管，不要上传。不同构建者的签名不同，不能保证覆盖安装他人构建的 APK。公开源码不预填个人蓝牙地址，请选择已配对电脑。

### Windows 构建

完整下载并解压源码，在 windows 文件夹运行：

- Win7 x86：`BUILD-AND-RUN-WIN7-X86.bat`
- Win11 x64：`BUILD-AND-RUN-WIN11-X64.bat`

脚本使用 .NET Framework 自带 csc.exe，成功后启动对应 bin 子目录中的 EXE，失败日志为 build.log。传输文字之前需要配置电脑 SPP 传入 COM 并开始监听；默认 COM3 不一定是实际端口。

### 测试

```sh
node protocol/protocol-test.js
```

Android 纯 Java 协议测试：编译 android/src/cn/remotemedwriter/android/Frame.java 与 android/tests/FrameTest.java，再运行 FrameTest。

Windows 协议测试：在 Windows 运行 windows/TEST-PROTOCOL-WIN7.bat。这里不宣称已执行该 Windows 测试。

## 两种通道的区别

| 文字传输 | 文件传输 |
| --- | --- |
| 需要本项目接收器监听 COM | 需要系统蓝牙“接收文件” |
| 接收后在记事本显示正文 | 接收后由系统保存原文件 |
| SPP 或 BLE 桥接器 | 系统蓝牙文件分享，仍需手动选择蓝牙和设备 |

目录监测不是蓝牙完成通知，也不能替代系统接收操作。它只看指定目录顶层的文件变化，其他软件写入也会触发；请使用专用接收目录。

## 隐私与已知限制

- APK 不声明互联网权限，但系统分享面板中的其他应用可能联网，请不要误选云盘或聊天应用。
- SHA-256 是完整性校验，不是应用层加密或身份认证。请核对接收设备并先用脱敏内容测试。
- 记事本写入失败时，回退文件存放在 `%TEMP%\RemoteMedWriter`，不自动删除。
- 图标为 AI 生成/适配素材，来源说明见 [ASSETS.md](ASSETS.md)。
- 仅在单位授权范围内连接内网电脑。不提供诊断或治疗建议。

## 许可证

采用 [MIT License](LICENSE)。允许使用、修改和再分发，需保留许可证声明；软件按现状提供，不保证适用于特定环境。

## 反馈

请提供手机型号、Android 版本、Windows 版本及位数、APK 版本、传输模式和脱敏错误信息。不要在 Issue 上传患者资料、密钥或个人设备地址。
