'use strict';

const crypto = require('crypto');
const assert = require('assert');

const MAX_PAYLOAD = 2 * 1024 * 1024;

function encode(text, id = crypto.randomUUID().replaceAll('-', '')) {
  const payload = Buffer.from(text, 'utf8');
  if (payload.length === 0 || payload.length > MAX_PAYLOAD) {
    throw new Error('invalid payload length');
  }
  const hash = crypto.createHash('sha256').update(payload).digest('hex');
  const header = Buffer.from(`RMW|1|${id}|${payload.length}|${hash}|\n`, 'ascii');
  const suffix = Buffer.from(`\nEND|${id}|\n`, 'ascii');
  return { id, payloadLength: payload.length, bytes: Buffer.concat([header, payload, suffix]) };
}

class Parser {
  constructor() {
    this.buffer = Buffer.alloc(0);
  }

  feed(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    const messages = [];
    const replies = [];

    while (true) {
      const newline = this.buffer.indexOf(0x0a);
      if (newline < 0) break;
      const header = this.buffer.subarray(0, newline).toString('ascii');
      const fields = header.split('|');
      if (fields.length !== 6 || fields[0] !== 'RMW' || fields[1] !== '1' || fields[5] !== '') {
        this.buffer = this.buffer.subarray(newline + 1);
        replies.push('NACK|unknown|BAD_HEADER\n');
        continue;
      }

      const [, , id, lengthText, expectedHash] = fields;
      const length = Number(lengthText);
      if (!/^[0-9a-fA-F]{32}$/.test(id) || !Number.isSafeInteger(length) || length <= 0) {
        this.buffer = this.buffer.subarray(newline + 1);
        replies.push('NACK|unknown|BAD_LENGTH\n');
        continue;
      }
      if (length > MAX_PAYLOAD) {
        this.buffer = this.buffer.subarray(newline + 1);
        replies.push(`NACK|${id}|TOO_LARGE\n`);
        continue;
      }

      const suffix = Buffer.from(`\nEND|${id}|\n`, 'ascii');
      const frameLength = newline + 1 + length + suffix.length;
      if (this.buffer.length < frameLength) break;

      const payloadStart = newline + 1;
      const payload = this.buffer.subarray(payloadStart, payloadStart + length);
      const actualSuffix = this.buffer.subarray(payloadStart + length, frameLength);
      this.buffer = this.buffer.subarray(frameLength);

      if (!actualSuffix.equals(suffix)) {
        replies.push(`NACK|${id}|BAD_SUFFIX\n`);
        continue;
      }
      const hash = crypto.createHash('sha256').update(payload).digest('hex');
      if (hash !== expectedHash.toLowerCase()) {
        replies.push(`NACK|${id}|BAD_HASH\n`);
        continue;
      }
      messages.push({ id, text: payload.toString('utf8'), byteLength: payload.length });
      replies.push(`ACK|${id}\n`);
    }

    return { messages, replies };
  }
}

function testChineseByteLength() {
  const frame = encode('主诉：发热三天。\n现病史：无。', '11111111111111111111111111111111');
  assert.strictEqual(frame.payloadLength, Buffer.byteLength('主诉：发热三天。\n现病史：无。', 'utf8'));
}

function testEveryPossibleSmallFragment() {
  const text = '入院记录\n主诉：咳嗽、发热。\n检验：WBC 8.2×10^9/L。';
  const frame = encode(text, '22222222222222222222222222222222');
  for (let chunkSize = 1; chunkSize <= 31; chunkSize += 1) {
    const parser = new Parser();
    const messages = [];
    const replies = [];
    for (let offset = 0; offset < frame.bytes.length; offset += chunkSize) {
      const result = parser.feed(frame.bytes.subarray(offset, offset + chunkSize));
      messages.push(...result.messages);
      replies.push(...result.replies);
    }
    assert.strictEqual(messages.length, 1, `chunk size ${chunkSize}`);
    assert.strictEqual(messages[0].text, text);
    assert.deepStrictEqual(replies, [`ACK|${frame.id}\n`]);
  }
}

function testStickyFrames() {
  const first = encode('第一份文字', '33333333333333333333333333333333');
  const second = encode('第二份文字\n第二行', '44444444444444444444444444444444');
  const result = new Parser().feed(Buffer.concat([first.bytes, second.bytes]));
  assert.deepStrictEqual(result.messages.map(item => item.text), ['第一份文字', '第二份文字\n第二行']);
  assert.strictEqual(result.replies.length, 2);
}

function testHashFailure() {
  const frame = encode('原始文字', '55555555555555555555555555555555');
  const headerEnd = frame.bytes.indexOf(0x0a);
  frame.bytes[headerEnd + 1] ^= 0x01;
  const result = new Parser().feed(frame.bytes);
  assert.strictEqual(result.messages.length, 0);
  assert.deepStrictEqual(result.replies, [`NACK|${frame.id}|BAD_HASH\n`]);
}

function testLongText() {
  const text = ('病程记录：患者今日一般情况稳定。\n').repeat(1000);
  const frame = encode(text, '66666666666666666666666666666666');
  const parser = new Parser();
  const messages = [];
  for (let offset = 0; offset < frame.bytes.length; offset += 997) {
    messages.push(...parser.feed(frame.bytes.subarray(offset, offset + 997)).messages);
  }
  assert.strictEqual(messages.length, 1);
  assert.strictEqual(messages[0].text, text);
}

const tests = [
  testChineseByteLength,
  testEveryPossibleSmallFragment,
  testStickyFrames,
  testHashFailure,
  testLongText,
];

for (const test of tests) {
  test();
  process.stdout.write(`PASS ${test.name}\n`);
}

process.stdout.write(`\n${tests.length} protocol tests passed.\n`);

