# RMW/1 蓝牙文字传输协议

## 帧结构

```text
RMW|1|<message_id>|<content_length>|<sha256>|\n
<content_length bytes of UTF-8 payload>
\nEND|<message_id>|\n
```

- `message_id`：32 位小写十六进制 UUID，不含连字符。
- `content_length`：UTF-8 内容的字节数，范围 1–2,097,152。
- `sha256`：payload 的 SHA-256，小写十六进制 64 字符。
- payload：用户主动选择的纯文本，编码固定为 UTF-8。
- 一个连接可以连续发送多个完整帧。

## 响应

成功：

```text
ACK|<message_id>\n
```

失败：

```text
NACK|<message_id>|<reason>\n
```

`reason` 仅使用 ASCII，例如 `BAD_HEADER`、`BAD_LENGTH`、`BAD_HASH`、`BAD_SUFFIX`、`TOO_LARGE`。

## 接收规则

1. 接收端按字节处理，不能假设一次串口读取就是一个完整帧。
2. 先读取到第一个 LF，解析 ASCII 头部。
3. 严格按 `content_length` 读取 payload。
4. 再读取并验证后缀。
5. 计算 SHA-256；通过后才显示正文并返回 ACK。
6. 同一个 `message_id` 再次到达时不重复追加正文，但仍返回 ACK，便于发送端安全重试。
7. 协议错误后丢弃当前帧并重新寻找以 `RMW|1|` 开始的头部。

## 隐私边界

- 协议不主动传输患者档案、图片、音频、设备标识或 API Key。
- 蓝牙配对和传输发生在手机与指定电脑之间。
- 蓝牙链路安全依赖操作系统配对和驱动；敏感生产环境仍需医院信息部门评估。

