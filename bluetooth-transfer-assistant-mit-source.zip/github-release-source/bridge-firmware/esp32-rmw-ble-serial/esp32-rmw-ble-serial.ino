#include <NimBLEDevice.h>

static const char *DEVICE_NAME = "RMW-BRIDGE-01";
static const char *SERVICE_UUID = "6E400001-B5A3-F393-E0A9-E50E24DCCA9E";
static const char *RX_UUID = "6E400002-B5A3-F393-E0A9-E50E24DCCA9E";
static const char *TX_UUID = "6E400003-B5A3-F393-E0A9-E50E24DCCA9E";

static NimBLECharacteristic *txCharacteristic = NULL;
static volatile bool clientConnected = false;

class RmwServerCallbacks : public NimBLEServerCallbacks {
  void onConnect(NimBLEServer *server, NimBLEConnInfo &connectionInfo) override {
    clientConnected = true;
  }

  void onDisconnect(NimBLEServer *server, NimBLEConnInfo &connectionInfo, int reason) override {
    clientConnected = false;
    NimBLEDevice::startAdvertising();
  }
};

class RmwRxCallbacks : public NimBLECharacteristicCallbacks {
  void onWrite(NimBLECharacteristic *characteristic, NimBLEConnInfo &connectionInfo) override {
    std::string value = characteristic->getValue();
    if (!value.empty()) {
      // 透明转发：不解码、不修改、不打印调试日志。
      Serial.write(reinterpret_cast<const uint8_t *>(value.data()), value.size());
      Serial.flush();
    }
  }
};

void setup() {
  // 板载 CP2102/CH340 在 Win7 上表现为普通 COM 端口。
  Serial.begin(115200);

  NimBLEDevice::init(DEVICE_NAME);
  NimBLEDevice::setMTU(247);

  NimBLEServer *server = NimBLEDevice::createServer();
  server->setCallbacks(new RmwServerCallbacks());

  NimBLEService *service = server->createService(SERVICE_UUID);
  service->createCharacteristic(
    RX_UUID,
    NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::WRITE_NR
  )->setCallbacks(new RmwRxCallbacks());

  txCharacteristic = service->createCharacteristic(
    TX_UUID,
    NIMBLE_PROPERTY::NOTIFY
  );

  service->start();
  NimBLEAdvertising *advertising = NimBLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->setName(DEVICE_NAME);
  advertising->enableScanResponse(true);
  advertising->start();
}

void loop() {
  if (!clientConnected || txCharacteristic == NULL || Serial.available() <= 0) {
    delay(2);
    return;
  }

  // Win7 接收器返回的 ACK/NACK 一般很短；每次最多通知 20 字节，兼容默认 MTU 23。
  uint8_t replyChunk[20];
  size_t count = 0;
  while (count < sizeof(replyChunk) && Serial.available() > 0) {
    int value = Serial.read();
    if (value < 0) break;
    replyChunk[count++] = static_cast<uint8_t>(value);
  }
  if (count > 0) {
    txCharacteristic->setValue(replyChunk, count);
    txCharacteristic->notify();
  }
}

